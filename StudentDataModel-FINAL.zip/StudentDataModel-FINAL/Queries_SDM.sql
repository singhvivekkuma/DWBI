/****** Core requirements and Elective Courses ******/
SELECT [DegreeProgram]
      ,[Requirement]
      ,[CourseID]
      ,[CourseName]
  FROM [StudentGraduateModel].[dbo].[Requirement_vw_1];

 ----Grades based on courses and sections----

SELECT [StudentID],[CourseID],[Section],[Semester],[SemesterYear],[Grade]
     FROM [StudentGraduateModel].[dbo].[Dim_StudentGrade_vw];

-----Enrollment and Drop Dates---
Select t.Semester,t.SemesterYear, de.FullDate as EnrollmentDate, dd.FullDate as DropDate from
(Select Semester, SemesterYear, EnrollmentDateSK
From Dim_Semester ) as T
Join [dbo].[Dim_Date] de on t.EnrollmentDateSK = de.DateSK
Join [dbo].[Dim_Date] dd on t.EnrollmentDateSK = dd.DateSK


-------------Who were the teachers in each class aboveSELECT [ClassSK],[CourseID],[CourseName],[FacultyName]   
  FROM [StudentGraduateModel].[dbo].[Requirement_vw_1];

------------What were the classes taught each semester---
SELECT ClassSk,CourseName,Semester,SemesterYear 
from dbo.Fact_Classes cl
JOIN dbo.Dim_Semester S on cl.SemesterSK = S.SemesterSK
JOIn dbo.Dim_Course C on c.CourseSK = cl.CourseSK;

------
SELECT Sem,
STUFF((Select DISTINCT ', '+COALESCE(CAST(CourseName as varchar),'')
FROM dbo.Dim_Course cs
FOR XML PATH ('')),1,2,'') as CoursesTought
FROM (SELECT c.CourseSK,CONCAT(Semester,',',SemesterYear) as Sem
from dbo.Fact_Classes cl
JOIN dbo.Dim_Semester S on cl.SemesterSK = S.SemesterSK
JOIn dbo.Dim_Course C on c.CourseSK = cl.CourseSK
Group by CONCAT(Semester,',',SemesterYear),c.CourseSK
) as t
Group BY Sem
Order by Sem desc;

------ What teachers taught classes in a degree program in a semester
SELECT ClassSk,t.CourseName,d.DegreeProgram,t.Semester,t.SemesterYear from
(SELECT ClassSk,cl.CourseSK, c.CourseName,Semester,SemesterYear 
from dbo.Fact_Classes cl
JOIN dbo.Dim_Semester S on cl.SemesterSK = S.SemesterSK
JOIN dbo.Dim_Course C on c.CourseSK = cl.CourseSK) as t
JOIN dbo.Dim_Requirement r on t.CourseSK = r.CourseSK
JOIN DBO.Dim_DegreeProgram d on r.DegreeProgramSK = d.DegreeProgramSK
Order by ClassSK;

-------------------Who are the students enrolled in a degree program--------------

Select [StudentID],[StudentName],[StudentEmail],DateOfBirth, CONCAT(hc,',',hs,',',hct) as Hometown,
CONCAT(ac,',',ast,',',act) as CurrentAddress from 
(SELECT [StudentID]
,[StudentName]
,[StudentEmail]
,d.FullDate as DateOfBirth
,g.city as hc
,g.state as hs
,g.country as hct
,ga.city as ac
,ga.state as ast
,ga.country as act
FROM [StudentGraduateModel].[dbo].[Dim_StudentInfo] s
JOIN dbo.Dim_GeoLoc g on s.StudentHometownSK = g.GeoSK
JOIN dbo.Dim_GeoLoc ga on s.StudentAddressSK = ga.GeoSK
JOIN dbo.Dim_Date d on s.DOBSK=d.DateSK) as t



