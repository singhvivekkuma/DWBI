
--IMDB BRANDS--
select count(*) as Count_Of_Brands_Gross                  from stg_imdb_brands_gross;
select count(*) as Count_Of_Brands_List                   from stg_imdb_brands_list;

--IMDB FRANCHISE--
select count(*) as Count_Of_Franchises_Gross              from stg_imdb_franchises_gross;
select count(*) as Count_Of_Franchises_List               from stg_imdb_franchises_list;

--IMDB NAME BASICS--
select count(*) as Count_Of_Name_Basics                   from stg_imdb_name_basics;
select count(*) as Count_Of_Name_Basics_knownForTitles    from stg_imdb_name_basics_knownForTitles;
select count(*) as Count_Of_Name_Basics_primaryProfession from stg_imdb_name_basics_primaryProfession;

--IMDB TITLES--
select count(*) as Count_Of_Title_Akas                    from stg_imdb_title_akas;
select count(*) as Count_Of_Title_Basics                  from stg_imdb_title_basics;
select count(*) as Count_Of_Title_Basics_Genres           from stg_imdb_title_basics_genres;
select count(*) as Count_Of_Title_Crew                    from stg_imdb_title_crew;
select count(*) as Count_Of_Title_Crew_Directors          from stg_imdb_title_crew_directors;
select count(*) as Count_Of_Title_Crew_Writers            from stg_imdb_title_crew_writers;
select count(*) as Count_Of_Title_Episode                 from stg_imdb_title_episode;
select count(*) as Count_Of_Title_Principals              from stg_imdb_title_principals;
select count(*) as Count_Of_Title_Principals              from stg_imdb_title_principals;
select count(*) as Count_Of_Title_Ratings                 from stg_imdb_title_ratings;

--IMDB ISO--
select count(*) as Count_Of_Iso_Country  from stg_iso_country;
select count(*) as Count_Of_Iso_Language from stg_iso_language;

--IMDB ML--
select count(*) as Count_Of_Genome_Scores from stg_ml_genome_scores
select count(*) as Count_Of_Genome_Tags   from stg_ml_genome_tags
select count(*) as Count_Of_ML_Links      from stg_ml_links
select count(*) as Count_Of_ML_Movies     from stg_ml_movies
select count(*) as Count_Of_ML_Ratings    from stg_ml_ratings
select count(*) as Count_Of_ML_Tags       from stg_ml_tags

--IMDB BOXOFFICE--
select count(*) as Count_Of_Daily_Box_Office              from stg_numbers_daily_box_office
select count(*) as Count_Of_Franchise_All_Box_Office      from stg_numbers_frachise_all_box_office
select count(*) as Count_Of_Franchise_Movies_Box_Office   from stg_numbers_frachise_movies_box_office
select count(*) as Count_Of_Box_Office_WorldWide          from stg_box_office_worldwide;




